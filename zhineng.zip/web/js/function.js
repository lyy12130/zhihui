function FocusItem (msg) {
     if($(msg).attr('name')=='veryCode'){
          $(msg).next().next().html('').removeClass('error');
     }
     else{
          $(msg).next('span').html('').removeClass('error');
     }
}
function checkItem(obj){
     var msgBox = $(obj).next('span');
     switch ($(obj).attr('name')) {
          case "userName":
               if(obj.value == ""){
                    msgBox.html('用户名不能为空');
                    msgBox.addClass('error');
               }else{
                    //url请求usernamecheck 传name  编码名字  对象obj   防止请求一个地址
                    var url="usernamecheck?name="+encodeURI($(obj).val()) + "&" + new  Date().getTime();
                    //false   true
                    //用ajax请求
                    $.get(url,function(data){
                         if(data == "false"){
                              msgBox.html('用户名已占用！');
                              msgBox.addClass('error');
                         }else{
                              msgBox.html().removeClass('error');
                         }
                    });
               }
               break;
          case "userSex":
               if(obj.value == ""){
                    msgBox.html('性别不能为空');
                    msgBox.addClass('error');
               }
               break;
          case "userBirthday":
               if(obj.value == ""){
                    msgBox.html('生日不能为空');
                    msgBox.addClass('error');
               }
               break;
          case "userMobile":
               if(obj.value == ""){
                    msgBox.html('电话不能为空');
                    msgBox.addClass('error');
               }
               break;
          case "userRepass":
               if(obj.value == ""){
                    msgBox.html('确认密码不能为空');
                    msgBox.addClass('error');
               }else if($(obj).val() != $('input[name="userPass"]').val()){
                    msgBox.html('两次输入密码不一致');
                    msgBox.addClass('error');
               }
               break;
          case "veryCode":
               var numshow = $(obj).next().next();

               if(obj.value == ""){
                    numshow.html('验证码不能为空');
                    numshow.addClass('error');
               }
               break;
     }
}