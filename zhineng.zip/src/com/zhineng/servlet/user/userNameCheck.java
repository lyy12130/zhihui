package com.zhineng.servlet.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*import com.zhineng.service.ZHINENG_USERDao;*/

/**
 * Servlet implementation class UsernameCheck
 */
@WebServlet("/usernamecheck")
public class userNameCheck extends HttpServlet {


}
