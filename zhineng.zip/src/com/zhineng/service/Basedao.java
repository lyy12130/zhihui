package com.zhineng.service;

public class Basedao {
    static {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        //加载驱动   驱动加载到java虚拟机中   加载过程值执行静态初始化

    }
    public connection getconn(){

    }
    public int exectuIUD(){}

    public void closeall(){

    }
}
