package com.zhineng.service;

import com.alibaba.fastjson.JSON;
import com.zhineng.bean.ResultInfo;
import com.zhineng.dao.UserDao;
import org.apache.catalina.User;

import java.util.List;

public class UserService {
    UserDao userDao = new UserDao();

    /**
     * 查询所有的用户数据
     * @return
     */
    public String queryAll() {
        //查询数据：调用dao层查询数据
        List<User> userList =  userDao.queryAll();

        //userList  ===>  JSON String
        String s = JSON.toJSONString(userList);

        return s;

    }


    /**
     * 处理注册业务的方法
     * @param user
     * @return
     */
    public String register(User user) {
        //0：添加了0条数据--添加失败    1：添加成功
        int addFlag =  userDao.addUser(user);

        //封装结果
        ResultInfo resultInfo = new ResultInfo();
        if (addFlag == 0) {
            resultInfo.setFlag(false);
        }else{
            resultInfo.setFlag(true);
        }

        String s = JSON.toJSONString(resultInfo);

        return s;
    }
}
